plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.malabelashab.v10"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.malabelashab.v10"
        minSdk = 23
        targetSdk = 35
        versionCode = 10
        versionName = "10.0"
    }
}
